package org.zerock.mapper;

import java.util.List;

import org.zerock.domain.BoardAttachVO;


public interface BoardAttachMapper {
	//첨부파일등록
	public void insert(BoardAttachVO vo);	
	//첨부파일삭제
	public void delete(String uuid);	
	//첨부파일목록
	public List<BoardAttachVO> findByBno(Long bno);
	//첨부파일모두삭제
	public void deleteAll(Long bno);
	//어제날짜첨부파일목록
	public List<BoardAttachVO> getOldFiles();
}
