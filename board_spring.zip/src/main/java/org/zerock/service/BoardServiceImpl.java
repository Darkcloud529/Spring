package org.zerock.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.zerock.domain.BoardAttachVO;
import org.zerock.domain.BoardVO;
import org.zerock.domain.Criteria;
import org.zerock.mapper.BoardAttachMapper;
import org.zerock.mapper.BoardMapper;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class BoardServiceImpl implements BoardService{

	@Setter(onMethod_ = @Autowired)
	private BoardMapper mapper;//자동주입
	
	@Setter(onMethod_ = @Autowired)
	private BoardAttachMapper attachMapper;//자동주입
	
	@Transactional
	@Override
	public void register(BoardVO board) {
		log.info("register....."+board);
		mapper.insertSelectKey(board);
		
		//attach파일 목록이 없으면 중지
		if(board.getAttachList()==null || board.getAttachList().size()<=0) {
			return;
		}
		//attach파일 하나씩 insert
		board.getAttachList().forEach(attach->{
			attach.setBno(board.getBno());
			attachMapper.insert(attach);
		});
	}

	@Override
	public BoardVO get(Long bno) {
		log.info("get....."+bno);
		return mapper.read(bno);
	}

	@Transactional
	@Override
	public boolean modify(BoardVO board) {
		attachMapper.deleteAll(board.getBno());

		boolean modifyResult = mapper.update(board) == 1;
		//부모글이 수정되고 첨부파일목록이 있을 경우
		if (modifyResult && board.getAttachList() !=null && board.getAttachList().size()>0) {

			board.getAttachList().forEach(attach -> {
				attach.setBno(board.getBno());
				attachMapper.insert(attach);//첨부파일등록
			});
		}
		return modifyResult;
	}

	@Transactional
	@Override
	public boolean remove(Long bno) {
		attachMapper.deleteAll(bno);//첨부파일삭제
		return mapper.delete(bno)==1;
	}

	//@Override
	//public List<BoardVO> getList() {
	//	log.info("getList.........");
	//	return mapper.getList();
	//}
	
	@Override
	public List<BoardVO> getList(Criteria cri) {		
		return mapper.getListWithPaging(cri);
	}

	@Override
	public int getTotal(Criteria cri) {		
		return mapper.getTotalCount(cri);
	}

	@Override
	public List<BoardAttachVO> getAttachList(Long bno) {		
		return attachMapper.findByBno(bno);
	}
	


}
