package org.zerock.domain;

import lombok.Getter;
import lombok.ToString;

@Getter
@ToString
public class PageDTO {

  private int startPage; // 시작페이지. 게시판목록 아래  1.2.3.4.5.6.7.8.9.10 에서 1에 해당
  private int endPage;   // 끝페이지. 게시판목록 아래 1.2.3.4.5.6.7.8.9.10 에서 10에 해당
  private boolean prev, next; // 이전, 다음 유무

  private int total;  //전체글수
  private Criteria cri; 

  public PageDTO(Criteria cri, int total) {

    this.cri = cri;
    this.total = total;

    //현재페이지가 5이면 끝페이지는 10을 구해야함
    this.endPage = (int) (Math.ceil(cri.getPageNum() / 10.0)) * 10;
    //시작페이지는 끝페이지(10)-9 = 1
    this.startPage = this.endPage - 9;

    //실제마지막페이지
    int realEnd = (int) (Math.ceil((total * 1.0) / cri.getAmount()));
    //실제마지막페이지가 계산으로 구한 마지막페이지보다 작으면 
    //계산으로 구한 마지막페이지를 실제마지막페이지로 교체
    if (realEnd <= this.endPage) {
      this.endPage = realEnd;
    }

    this.prev = this.startPage > 1; //시작페이지가 1보다 커야 이전페이지 존재 true

    this.next = this.endPage < realEnd;  // 계산으로 구한 마지막페이지가 실제마지막페이지보다 작아야 다음페이지 존재 true
  }
  
}

